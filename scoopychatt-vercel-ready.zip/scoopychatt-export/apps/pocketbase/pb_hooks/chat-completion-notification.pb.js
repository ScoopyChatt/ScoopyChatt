/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  // Only send notification for assistant messages
  if (e.record.get("role") !== "assistant") {
    e.next();
    return;
  }

  const userId = e.record.get("userId");
  if (!userId) {
    e.next();
    return;
  }

  try {
    // Fetch the user record to get their email
    const user = $app.findRecordById("users", userId);
    if (!user) {
      console.log("User not found for ID: " + userId);
      e.next();
      return;
    }

    const userEmail = user.get("email");
    const userName = user.get("name") || "User";

    // Fetch all messages for this user to build the transcript
    const messages = $app.findRecordsByFilter(
      "_integratedAiMessages",
      "userId = '" + userId + "'",
      "-created",
      100
    );

    // Build a summary of the conversation
    let conversationSummary = "";
    let userMessageCount = 0;
    let assistantMessageCount = 0;

    for (let i = messages.length - 1; i >= 0; i--) {
      const msg = messages[i];
      const role = msg.get("role");
      const content = msg.get("content");

      if (role === "user") {
        userMessageCount++;
        conversationSummary += "<p><strong>You:</strong> " + escapeHtml(JSON.stringify(content)) + "</p>";
      } else if (role === "assistant") {
        assistantMessageCount++;
        conversationSummary += "<p><strong>Assistant:</strong> " + escapeHtml(JSON.stringify(content)) + "</p>";
      }
    }

    // Create the email message
    const message = new MailerMessage({
      from: {
        address: $app.settings().meta.senderAddress,
        name: $app.settings().meta.senderName
      },
      to: [{ address: userEmail }],
      subject: "Chat Conversation Completed",
      html: "<h2>Hello " + escapeHtml(userName) + ",</h2>" +
            "<p>Your chat conversation has been completed and processed.</p>" +
            "<h3>Conversation Summary:</h3>" +
            "<div style=\"background-color: #f5f5f5; padding: 15px; border-radius: 5px;\">" +
            conversationSummary +
            "</div>" +
            "<p><strong>Statistics:</strong></p>" +
            "<ul>" +
            "<li>Your messages: " + userMessageCount + "</li>" +
            "<li>Assistant responses: " + assistantMessageCount + "</li>" +
            "</ul>" +
            "<p>Thank you for using our chat service. If you have any questions, please don't hesitate to reach out.</p>" +
            "<p>Best regards,<br>The Support Team</p>"
    });

    // Send the email
    $app.newMailClient().send(message);
    console.log("Notification email sent to " + userEmail + " for user " + userId);

  } catch (error) {
    console.log("Error sending notification email: " + error.message);
  }

  e.next();
}, "_integratedAiMessages");

// Helper function to escape HTML special characters
function escapeHtml(text) {
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#039;"
  };
  return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
}
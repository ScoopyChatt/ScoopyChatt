/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  // Extract quote request data
  const name = e.record.get("name");
  const email = e.record.get("email");
  const phone = e.record.get("phone");
  const serviceZipCode = e.record.get("serviceZipCode");
  const serviceType = e.record.get("serviceType");
  const additionalNotes = e.record.get("additionalNotes");
  const numberOfDogs = e.record.get("numberOfDogs");
  const recordId = e.record.id;

  // Create email body HTML
  const emailBody = `
    <h2>New Quote Request Received</h2>
    <p><strong>Request ID:</strong> ${recordId}</p>
    <hr>
    <h3>Customer Information</h3>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Phone:</strong> ${phone}</p>
    <hr>
    <h3>Service Details</h3>
    <p><strong>Service Type:</strong> ${serviceType}</p>
    <p><strong>Service Zip Code:</strong> ${serviceZipCode}</p>
    <p><strong>Number of Dogs:</strong> ${numberOfDogs}</p>
    ${additionalNotes ? `<p><strong>Additional Notes:</strong></p><p>${additionalNotes}</p>` : ''}
    <hr>
    <p><em>Please follow up with the customer at your earliest convenience.</em></p>
  `;

  // Send email to brandon@scoopychatt.com
  const messageBrandon = new MailerMessage({
    from: {
      address: $app.settings().meta.senderAddress,
      name: $app.settings().meta.senderName
    },
    to: [{ address: "brandon@scoopychatt.com" }],
    subject: `New Quote Request from ${name}`,
    html: emailBody
  });
  $app.newMailClient().send(messageBrandon);

  // Send email to info@scoopychatt.com
  const messageInfo = new MailerMessage({
    from: {
      address: $app.settings().meta.senderAddress,
      name: $app.settings().meta.senderName
    },
    to: [{ address: "info@scoopychatt.com" }],
    subject: `New Quote Request from ${name}`,
    html: emailBody
  });
  $app.newMailClient().send(messageInfo);

  e.next();
}, "quote_requests");
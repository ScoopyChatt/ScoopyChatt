/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("blog_posts");

  const existing = collection.fields.getByName("content");
  if (existing) {
    if (existing.type === "editor") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("content"); // exists with wrong type, remove first
  }

  collection.fields.add(new EditorField({
    name: "content",
    required: true
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("blog_posts");
    collection.fields.removeByName("content");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})

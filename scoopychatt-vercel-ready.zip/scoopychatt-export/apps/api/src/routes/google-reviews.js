import express from 'express';
import logger from '../utils/logger.js';
import { getCachedReviews } from '../services/google-reviews-service.js';

const router = express.Router();

/**
 * GET /google-reviews
 * Fetch all Google reviews with complete data
 * Returns: { overallRating: 5, totalReviews: 82, reviews: [...] }
 */
router.get('/', async (req, res) => {
  logger.info('GET /google-reviews request received', {
    timestamp: new Date().toISOString(),
  });

  const reviewData = await getCachedReviews();

  logger.info('Returning Google reviews', {
    overallRating: reviewData.overallRating,
    totalReviews: reviewData.totalReviews,
    reviewsCount: reviewData.reviews.length,
    timestamp: new Date().toISOString(),
  });

  // Return the complete review data object
  res.json(reviewData);
});

export default router;
import express from 'express';
import logger from '../utils/logger.js';
import pb from '../utils/pocketbaseClient.js';

const router = express.Router();
const BUSINESS_OWNER_EMAIL = 'brandon@scoopychatt.com';

/**
 * POST /chat-summary/send-summary
 * Send a post-chat notification email to business owner with conversation summary
 * Accepts the chat transcript, user info, and business owner email
 * @param {Object} req.body
 * @param {string} req.body.userId - User ID from PocketBase
 * @param {Array} req.body.conversationMessages - Array of chat messages with role and content
 * @param {string} req.body.userEmail - User's email address
 * @param {string} req.body.userName - User's name
 * @param {string} req.body.businessOwnerEmail - Business owner's email (recipient)
 * @returns {Object} { success: true, message: 'Email sent to business owner', summaryId: string }
 */
router.post('/send-summary', async (req, res) => {
  const { userId, conversationMessages, userEmail, userName, businessOwnerEmail } = req.body;

  // Validate required fields
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }

  if (!conversationMessages || !Array.isArray(conversationMessages)) {
    return res.status(400).json({ error: 'conversationMessages array is required' });
  }

  if (!userEmail) {
    return res.status(400).json({ error: 'userEmail is required' });
  }

  if (!businessOwnerEmail) {
    return res.status(400).json({ error: 'businessOwnerEmail is required' });
  }

  logger.info('Chat summary send-summary request received', {
    userId,
    userEmail,
    userName: userName || 'Not provided',
    businessOwnerEmail,
    messageCount: conversationMessages.length,
    timestamp: new Date().toISOString(),
  });

  // Format the conversation transcript
  const conversationTranscript = formatConversationTranscript(conversationMessages);
  const summary = generateConversationSummary(conversationMessages);

  logger.info('Formatted conversation transcript and summary', {
    userId,
    transcriptLength: conversationTranscript.length,
    summaryLength: summary.length,
    timestamp: new Date().toISOString(),
  });

  // Generate email HTML body
  const emailBody = formatChatSummaryEmailForBusinessOwner({
    userName: userName || 'Customer',
    userEmail,
    conversationTranscript,
    summary,
    messageCount: conversationMessages.length,
  });

  logger.info('Generated email HTML body', {
    userId,
    businessOwnerEmail,
    bodyLength: emailBody.length,
    timestamp: new Date().toISOString(),
  });

  // Send email using PocketBase's built-in mailer
  const emailData = {
    to: businessOwnerEmail,
    subject: `Chat Summary - ${userName || 'Customer'} (${userEmail})`,
    html: emailBody,
  };

  logger.info('Sending chat summary email via PocketBase', {
    to: emailData.to,
    subject: emailData.subject,
    userId,
    timestamp: new Date().toISOString(),
  });

  // Use PocketBase's built-in mailer
  await pb.send(emailData.to, {
    subject: emailData.subject,
    html: emailData.html,
  });

  logger.info('Chat summary email sent successfully via PocketBase', {
    to: emailData.to,
    subject: emailData.subject,
    userId,
    timestamp: new Date().toISOString(),
  });

  // Save the summary record to 'chat_summaries' collection
  const summaryRecord = await pb.collection('chat_summaries').create({
    userId,
    userEmail,
    userName: userName || 'Customer',
    conversationTranscript,
    summary,
    messageCount: conversationMessages.length,
    sentAt: new Date().toISOString(),
  });

  logger.info('Chat summary record saved to PocketBase', {
    recordId: summaryRecord.id,
    userId,
    userEmail,
    timestamp: new Date().toISOString(),
  });

  res.status(200).json({
    success: true,
    message: 'Email sent to business owner',
    summaryId: summaryRecord.id,
  });
});

/**
 * POST /chat-summary
 * Send a post-chat notification email with conversation summary
 * Accepts the chat transcript and user email
 * @param {Object} req.body
 * @param {string} req.body.userEmail - User's email address
 * @param {string} req.body.userName - User's name
 * @param {Array} req.body.messages - Array of chat messages with role and content
 * @param {string} req.body.conversationStartTime - ISO timestamp of conversation start
 * @returns {Object} { success: true, message: 'Email sent successfully' }
 */
router.post('/', async (req, res) => {
  const { userEmail, userName, messages, conversationStartTime } = req.body;

  // Validate required fields
  if (!userEmail) {
    return res.status(400).json({ error: 'userEmail is required' });
  }

  if (!userName) {
    return res.status(400).json({ error: 'userName is required' });
  }

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'messages array is required' });
  }

  if (!conversationStartTime) {
    return res.status(400).json({ error: 'conversationStartTime is required' });
  }

  logger.info('Chat summary request received', {
    userEmail,
    userName,
    messageCount: messages.length,
    conversationStartTime,
    timestamp: new Date().toISOString(),
  });

  // Format the conversation into a readable email body
  const emailBody = formatChatSummaryEmail({
    userName,
    userEmail,
    conversationStartTime,
    messages,
  });

  logger.info('Formatted chat summary email body', {
    userEmail,
    bodyLength: emailBody.length,
    timestamp: new Date().toISOString(),
  });

  // Send email to business owner using PocketBase's built-in mailer
  const emailData = {
    to: BUSINESS_OWNER_EMAIL,
    subject: `Chat Summary - ${userName}`,
    html: emailBody,
  };

  logger.info('Sending chat summary email to business owner via PocketBase', {
    to: emailData.to,
    subject: emailData.subject,
    userEmail,
    userName,
    timestamp: new Date().toISOString(),
  });

  // Use PocketBase's built-in mailer
  await pb.send(emailData.to, {
    subject: emailData.subject,
    html: emailData.html,
  });

  logger.info('Chat summary email sent successfully to business owner via PocketBase', {
    to: emailData.to,
    subject: emailData.subject,
    userEmail,
    userName,
    timestamp: new Date().toISOString(),
  });

  res.status(200).json({
    success: true,
    message: 'Chat summary email sent successfully',
  });
});

/**
 * Format the conversation into a readable text transcript
 * @param {Array} messages - Array of chat messages
 * @returns {string} Formatted text transcript
 */
function formatConversationTranscript(messages) {
  const timestamp = new Date().toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  let transcript = `CONVERSATION TRANSCRIPT\n`;
  transcript += `Generated: ${timestamp}\n`;
  transcript += `Total Messages: ${messages.length}\n`;
  transcript += `${'='.repeat(80)}\n\n`;

  messages.forEach((msg, index) => {
    const role = msg.role || 'unknown';
    const roleLabel = role.charAt(0).toUpperCase() + role.slice(1);
    const content = msg.content || '';

    transcript += `[${index + 1}] ${roleLabel}:\n`;
    transcript += `${content}\n`;
    transcript += `${'-'.repeat(80)}\n\n`;
  });

  return transcript;
}

/**
 * Generate a brief summary of the conversation
 * @param {Array} messages - Array of chat messages
 * @returns {string} Conversation summary
 */
function generateConversationSummary(messages) {
  const userMessages = messages.filter(m => m.role === 'user');
  const assistantMessages = messages.filter(m => m.role === 'assistant');

  // Extract key topics from user messages
  const topics = extractTopics(userMessages);

  let summary = `CONVERSATION SUMMARY\n`;
  summary += `${'='.repeat(80)}\n\n`;
  summary += `Total Messages: ${messages.length}\n`;
  summary += `User Messages: ${userMessages.length}\n`;
  summary += `Assistant Responses: ${assistantMessages.length}\n\n`;

  if (topics.length > 0) {
    summary += `Key Topics Discussed:\n`;
    topics.forEach((topic, index) => {
      summary += `${index + 1}. ${topic}\n`;
    });
  } else {
    summary += `No specific topics identified.\n`;
  }

  summary += `\nConversation Status: Completed\n`;

  return summary;
}

/**
 * Extract key topics from user messages
 * @param {Array} userMessages - Array of user messages
 * @returns {Array} Array of topic strings
 */
function extractTopics(userMessages) {
  const topics = [];
  const keywords = [
    'pricing',
    'service',
    'dogs',
    'schedule',
    'frequency',
    'cost',
    'address',
    'location',
    'phone',
    'contact',
    'quote',
    'information',
    'help',
    'question',
  ];

  userMessages.forEach(msg => {
    const content = (msg.content || '').toLowerCase();
    keywords.forEach(keyword => {
      if (content.includes(keyword) && !topics.includes(keyword)) {
        topics.push(keyword.charAt(0).toUpperCase() + keyword.slice(1));
      }
    });
  });

  return topics.slice(0, 5); // Return top 5 topics
}

/**
 * Format the chat conversation into a readable HTML email body for business owner
 * @param {Object} params - Parameters object
 * @param {string} params.userName - User's name
 * @param {string} params.userEmail - User's email
 * @param {string} params.conversationTranscript - Full conversation transcript
 * @param {string} params.summary - Conversation summary
 * @param {number} params.messageCount - Total number of messages
 * @returns {string} Formatted HTML email body
 */
function formatChatSummaryEmailForBusinessOwner({
  userName,
  userEmail,
  conversationTranscript,
  summary,
  messageCount,
}) {
  const timestamp = new Date().toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          background-color: #f9f9f9;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          background-color: #ffffff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .header {
          border-bottom: 3px solid #0066cc;
          padding-bottom: 15px;
          margin-bottom: 20px;
        }
        .header h1 {
          margin: 0 0 10px 0;
          color: #0066cc;
          font-size: 24px;
        }
        .section {
          margin-bottom: 25px;
        }
        .section-title {
          font-size: 16px;
          font-weight: bold;
          color: #0066cc;
          border-bottom: 2px solid #e0e0e0;
          padding-bottom: 8px;
          margin-bottom: 12px;
        }
        .info-row {
          display: flex;
          margin-bottom: 8px;
        }
        .info-label {
          font-weight: bold;
          width: 150px;
          color: #555;
        }
        .info-value {
          color: #333;
          flex: 1;
          word-break: break-word;
        }
        .transcript {
          background-color: #f5f5f5;
          padding: 15px;
          border-radius: 4px;
          max-height: 800px;
          overflow-y: auto;
          font-family: 'Courier New', monospace;
          font-size: 12px;
          white-space: pre-wrap;
          word-wrap: break-word;
        }
        .summary {
          background-color: #f0f8ff;
          padding: 15px;
          border-left: 4px solid #0066cc;
          border-radius: 4px;
          font-family: 'Courier New', monospace;
          font-size: 12px;
          white-space: pre-wrap;
          word-wrap: break-word;
        }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #e0e0e0;
          font-size: 12px;
          color: #999;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🐕 Chat Summary - Business Owner Report</h1>
          <p style="margin: 0; color: #666; font-size: 14px;">A customer has completed a chat conversation with your AI assistant</p>
        </div>

        <div class="section">
          <div class="section-title">Customer Information</div>
          <div class="info-row">
            <div class="info-label">Name:</div>
            <div class="info-value">${escapeHtml(userName)}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Email:</div>
            <div class="info-value"><a href="mailto:${escapeHtml(userEmail)}">${escapeHtml(userEmail)}</a></div>
          </div>
          <div class="info-row">
            <div class="info-label">Total Messages:</div>
            <div class="info-value">${messageCount}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Report Generated:</div>
            <div class="info-value">${timestamp}</div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Conversation Summary</div>
          <div class="summary">${escapeHtml(summary)}</div>
        </div>

        <div class="section">
          <div class="section-title">Full Chat Transcript</div>
          <div class="transcript">${escapeHtml(conversationTranscript)}</div>
        </div>

        <div class="section">
          <p style="color: #666; font-size: 14px; line-height: 1.6;">
            This email contains a complete record of the customer's chat conversation with your AI assistant. Use this information to follow up with the customer or improve your service offerings.
          </p>
        </div>

        <div class="footer">
          <p>This email was automatically generated from a chat conversation on your Scoopy website.</p>
          <p>Sent at: ${new Date().toISOString()}</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return emailHtml;
}

/**
 * Format the chat conversation into a readable HTML email body
 * @param {Object} params - Parameters object
 * @param {string} params.userName - User's name
 * @param {string} params.userEmail - User's email
 * @param {string} params.conversationStartTime - ISO timestamp of conversation start
 * @param {Array} params.messages - Array of chat messages
 * @returns {string} Formatted HTML email body
 */
function formatChatSummaryEmail({ userName, userEmail, conversationStartTime, messages }) {
  // Format the conversation timestamp
  const conversationDate = new Date(conversationStartTime);
  const formattedDate = conversationDate.toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  // Calculate conversation duration
  const endTime = new Date();
  const durationMs = endTime - conversationDate;
  const durationMinutes = Math.floor(durationMs / 60000);
  const durationSeconds = Math.floor((durationMs % 60000) / 1000);
  const durationText = durationMinutes > 0
    ? `${durationMinutes} minute${durationMinutes !== 1 ? 's' : ''} ${durationSeconds} second${durationSeconds !== 1 ? 's' : ''}`
    : `${durationSeconds} second${durationSeconds !== 1 ? 's' : ''}`;

  // Format the chat transcript
  const transcriptHtml = messages
    .map((msg) => {
      const role = msg.role || 'unknown';
      const content = msg.content || '';
      const roleLabel = role.charAt(0).toUpperCase() + role.slice(1);

      return `
        <div style="margin-bottom: 12px; padding: 10px; background-color: ${role === 'user' ? '#f0f0f0' : '#e8f4f8'}; border-left: 4px solid ${role === 'user' ? '#999' : '#0066cc'}; border-radius: 4px;">
          <strong style="color: ${role === 'user' ? '#333' : '#0066cc'};">${roleLabel}:</strong>
          <p style="margin: 8px 0 0 0; color: #333; line-height: 1.5;">${escapeHtml(content)}</p>
        </div>
      `;
    })
    .join('');

  // Count user and assistant messages
  const userMessageCount = messages.filter(m => m.role === 'user').length;
  const assistantMessageCount = messages.filter(m => m.role === 'assistant').length;

  // Build the complete email HTML
  const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          background-color: #f9f9f9;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          background-color: #ffffff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .header {
          border-bottom: 3px solid #0066cc;
          padding-bottom: 15px;
          margin-bottom: 20px;
        }
        .header h1 {
          margin: 0 0 10px 0;
          color: #0066cc;
          font-size: 24px;
        }
        .section {
          margin-bottom: 25px;
        }
        .section-title {
          font-size: 16px;
          font-weight: bold;
          color: #0066cc;
          border-bottom: 2px solid #e0e0e0;
          padding-bottom: 8px;
          margin-bottom: 12px;
        }
        .info-row {
          display: flex;
          margin-bottom: 8px;
        }
        .info-label {
          font-weight: bold;
          width: 150px;
          color: #555;
        }
        .info-value {
          color: #333;
          flex: 1;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 15px;
          margin-bottom: 15px;
        }
        .stat-box {
          background-color: #f5f5f5;
          padding: 12px;
          border-radius: 4px;
          text-align: center;
        }
        .stat-number {
          font-size: 24px;
          font-weight: bold;
          color: #0066cc;
        }
        .stat-label {
          font-size: 12px;
          color: #666;
          margin-top: 4px;
        }
        .transcript {
          background-color: #f5f5f5;
          padding: 15px;
          border-radius: 4px;
          max-height: 600px;
          overflow-y: auto;
        }
        .cta-button {
          display: inline-block;
          background-color: #0066cc;
          color: white;
          padding: 12px 24px;
          border-radius: 4px;
          text-decoration: none;
          font-weight: bold;
          margin-top: 15px;
        }
        .cta-button:hover {
          background-color: #0052a3;
        }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #e0e0e0;
          font-size: 12px;
          color: #999;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🐕 Chat Summary - ${escapeHtml(userName)}</h1>
          <p style="margin: 0; color: #666; font-size: 14px;">Customer chat conversation summary from Scoopy AI Assistant</p>
        </div>

        <div class="section">
          <div class="section-title">Conversation Overview</div>
          <div class="info-row">
            <div class="info-label">Customer Name:</div>
            <div class="info-value">${escapeHtml(userName)}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Email:</div>
            <div class="info-value">${escapeHtml(userEmail)}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Start Time:</div>
            <div class="info-value">${formattedDate}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Duration:</div>
            <div class="info-value">${durationText}</div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Conversation Statistics</div>
          <div class="stats-grid">
            <div class="stat-box">
              <div class="stat-number">${userMessageCount}</div>
              <div class="stat-label">Customer Messages</div>
            </div>
            <div class="stat-box">
              <div class="stat-number">${assistantMessageCount}</div>
              <div class="stat-label">AI Responses</div>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Full Chat Transcript</div>
          <div class="transcript">
            ${transcriptHtml}
          </div>
        </div>

        <div class="section">
          <p style="color: #666; font-size: 14px; line-height: 1.6;">
            This email contains a complete record of the customer's chat conversation with your AI assistant. Review this transcript to understand customer needs and follow up appropriately.
          </p>
        </div>

        <div class="footer">
          <p>This email was automatically generated from a chat conversation on Scoopy's website.</p>
          <p>Sent at: ${new Date().toISOString()}</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return emailHtml;
}

/**
 * Escape HTML special characters to prevent injection
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  };
  return String(text).replace(/[&<>"']/g, (char) => map[char]);
}

export default router;
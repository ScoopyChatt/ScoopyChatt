import express from 'express';
import axios from 'axios';
import logger from '../utils/logger.js';

const router = express.Router();

router.get('/', async (req, res) => {
  const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY;
  const GOOGLE_BUSINESS_PROFILE_ID = process.env.GOOGLE_BUSINESS_PROFILE_ID;

  logger.info('=== GOOGLE PLACES API DIAGNOSTIC TEST ===');
  logger.info('Test initiated', {
    timestamp: new Date().toISOString(),
    hasApiKey: !!GOOGLE_PLACES_API_KEY,
    apiKeyPrefix: GOOGLE_PLACES_API_KEY ? GOOGLE_PLACES_API_KEY.substring(0, 10) + '...' : 'NOT SET',
    businessProfileId: GOOGLE_BUSINESS_PROFILE_ID,
  });

  if (!GOOGLE_PLACES_API_KEY) {
    logger.error('GOOGLE_PLACES_API_KEY is not set in environment variables');
    return res.status(500).json({
      success: false,
      error: 'GOOGLE_PLACES_API_KEY is not configured in .env',
      details: 'Please ensure GOOGLE_PLACES_API_KEY is set in apps/api/.env',
    });
  }

  const testResults = {
    success: false,
    tests: {},
    timestamp: new Date().toISOString(),
  };

  // Test 1: Raw Business Profile ID format
  logger.info('=== TEST 1: Raw Business Profile ID Format ===');
  const test1Url = `https://places.googleapis.com/v1/places/${GOOGLE_BUSINESS_PROFILE_ID}`;
  const test1Params = {
    fields: 'reviews',
    key: GOOGLE_PLACES_API_KEY,
  };
  const test1Headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'User-Agent': 'Scoopy-API/1.0',
  };

  const test1CurlCommand = `curl -X GET "${test1Url}?fields=reviews&key=${GOOGLE_PLACES_API_KEY.substring(0, 10)}..." -H "Accept: application/json" -H "Content-Type: application/json" -H "User-Agent: Scoopy-API/1.0"`;
  logger.info('EQUIVALENT_CURL_COMMAND:', {
    command: test1CurlCommand,
    timestamp: new Date().toISOString(),
  });

  logger.info('GOOGLE_REQUEST_URL:', {
    url: test1Url,
    method: 'GET',
    timestamp: new Date().toISOString(),
  });
  logger.info('GOOGLE_REQUEST_HEADERS:', {
    Accept: test1Headers.Accept,
    ContentType: test1Headers['Content-Type'],
    UserAgent: test1Headers['User-Agent'],
    timestamp: new Date().toISOString(),
  });

  try {
    logger.info('Making HTTP GET request (raw ID format)...', {
      url: test1Url,
      timeout: 10000,
      timestamp: new Date().toISOString(),
    });

    const test1Response = await axios.get(test1Url, {
      params: test1Params,
      timeout: 10000,
      headers: test1Headers,
    });

    logger.info('GOOGLE_RESPONSE_STATUS:', {
      statusCode: test1Response.status,
      statusText: test1Response.statusText,
      timestamp: new Date().toISOString(),
    });
    logger.info('GOOGLE_RESPONSE_HEADERS:', {
      contentType: test1Response.headers['content-type'],
      contentLength: test1Response.headers['content-length'],
      cacheControl: test1Response.headers['cache-control'],
      xGoogRequestId: test1Response.headers['x-goog-request-id'],
      allHeaders: JSON.stringify(test1Response.headers).substring(0, 500),
      timestamp: new Date().toISOString(),
    });
    logger.info('GOOGLE_RESPONSE_BODY:', {
      body: JSON.stringify(test1Response.data).substring(0, 2000),
      totalLength: JSON.stringify(test1Response.data).length,
      timestamp: new Date().toISOString(),
    });

    testResults.tests.rawBusinessProfileId = {
      status: 'PASSED',
      httpStatus: test1Response.status,
      statusText: test1Response.statusText,
      responseKeys: Object.keys(test1Response.data),
      placesFound: test1Response.data.places?.length || 0,
      reviewsFound: test1Response.data.reviews?.length || 0,
      curlCommand: test1CurlCommand,
    };
  } catch (error) {
    logger.error('=== TEST 1 FAILED ===');
    logger.error('Error details', {
      message: error.message,
      code: error.code,
      status: error.response?.status,
      statusText: error.response?.statusText,
      GOOGLE_RESPONSE_BODY: error.response?.data ? JSON.stringify(error.response.data).substring(0, 1000) : 'No response body',
      timestamp: new Date().toISOString(),
    });

    testResults.tests.rawBusinessProfileId = {
      status: 'FAILED',
      httpStatus: error.response?.status || 'N/A',
      statusText: error.response?.statusText || error.message,
      errorMessage: error.message,
      errorCode: error.code,
      responseBody: error.response?.data ? JSON.stringify(error.response.data).substring(0, 500) : 'No response body',
      curlCommand: test1CurlCommand,
    };
  }

  // Test 2: Prefixed Business Profile ID format (places/ID)
  logger.info('=== TEST 2: Prefixed Business Profile ID Format (places/ID) ===');
  const test2Url = `https://places.googleapis.com/v1/places/places/${GOOGLE_BUSINESS_PROFILE_ID}`;
  const test2Params = {
    fields: 'reviews',
    key: GOOGLE_PLACES_API_KEY,
  };

  const test2CurlCommand = `curl -X GET "${test2Url}?fields=reviews&key=${GOOGLE_PLACES_API_KEY.substring(0, 10)}..." -H "Accept: application/json" -H "Content-Type: application/json" -H "User-Agent: Scoopy-API/1.0"`;
  logger.info('EQUIVALENT_CURL_COMMAND:', {
    command: test2CurlCommand,
    timestamp: new Date().toISOString(),
  });

  logger.info('GOOGLE_REQUEST_URL:', {
    url: test2Url,
    method: 'GET',
    timestamp: new Date().toISOString(),
  });

  try {
    logger.info('Making HTTP GET request (prefixed ID format)...', {
      url: test2Url,
      timeout: 10000,
      timestamp: new Date().toISOString(),
    });

    const test2Response = await axios.get(test2Url, {
      params: test2Params,
      timeout: 10000,
      headers: test1Headers,
    });

    logger.info('GOOGLE_RESPONSE_STATUS:', {
      statusCode: test2Response.status,
      statusText: test2Response.statusText,
      timestamp: new Date().toISOString(),
    });
    logger.info('GOOGLE_RESPONSE_HEADERS:', {
      contentType: test2Response.headers['content-type'],
      contentLength: test2Response.headers['content-length'],
      cacheControl: test2Response.headers['cache-control'],
      xGoogRequestId: test2Response.headers['x-goog-request-id'],
      timestamp: new Date().toISOString(),
    });
    logger.info('GOOGLE_RESPONSE_BODY:', {
      body: JSON.stringify(test2Response.data).substring(0, 2000),
      totalLength: JSON.stringify(test2Response.data).length,
      timestamp: new Date().toISOString(),
    });

    testResults.tests.prefixedBusinessProfileId = {
      status: 'PASSED',
      httpStatus: test2Response.status,
      statusText: test2Response.statusText,
      responseKeys: Object.keys(test2Response.data),
      placesFound: test2Response.data.places?.length || 0,
      reviewsFound: test2Response.data.reviews?.length || 0,
      curlCommand: test2CurlCommand,
    };
  } catch (error) {
    logger.error('=== TEST 2 FAILED ===');
    logger.error('Error details', {
      message: error.message,
      code: error.code,
      status: error.response?.status,
      statusText: error.response?.statusText,
      GOOGLE_RESPONSE_BODY: error.response?.data ? JSON.stringify(error.response.data).substring(0, 1000) : 'No response body',
      timestamp: new Date().toISOString(),
    });

    testResults.tests.prefixedBusinessProfileId = {
      status: 'FAILED',
      httpStatus: error.response?.status || 'N/A',
      statusText: error.response?.statusText || error.message,
      errorMessage: error.message,
      errorCode: error.code,
      responseBody: error.response?.data ? JSON.stringify(error.response.data).substring(0, 500) : 'No response body',
      curlCommand: test2CurlCommand,
    };
  }

  // Test 3: searchNearby as fallback to verify API key works
  logger.info('=== TEST 3: searchNearby Fallback (verify API key works) ===');
  const test3Url = 'https://places.googleapis.com/v1/places:searchNearby';
  const test3Payload = {
    locationRestriction: {
      circle: {
        center: {
          latitude: -33.8688,
          longitude: 151.2093,
        },
        radius: 1000.0,
      },
    },
  };
  const test3Headers = {
    'Content-Type': 'application/json',
    'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
    'User-Agent': 'Scoopy-API/1.0',
  };

  const test3CurlCommand = `curl -X POST "${test3Url}" -H "Content-Type: application/json" -H "X-Goog-Api-Key: ${GOOGLE_PLACES_API_KEY.substring(0, 10)}..." -H "User-Agent: Scoopy-API/1.0" -d '{"locationRestriction": {"circle": {"center": {"latitude": -33.8688, "longitude": 151.2093}, "radius": 1000.0}}}'`;
  logger.info('EQUIVALENT_CURL_COMMAND:', {
    command: test3CurlCommand,
    timestamp: new Date().toISOString(),
  });

  logger.info('GOOGLE_REQUEST_URL:', {
    url: test3Url,
    method: 'POST',
    timestamp: new Date().toISOString(),
  });
  logger.info('GOOGLE_REQUEST_HEADERS:', {
    ContentType: test3Headers['Content-Type'],
    XGoogApiKey: test3Headers['X-Goog-Api-Key'].substring(0, 10) + '...',
    UserAgent: test3Headers['User-Agent'],
    timestamp: new Date().toISOString(),
  });
  logger.info('GOOGLE_REQUEST_BODY:', {
    body: JSON.stringify(test3Payload),
    timestamp: new Date().toISOString(),
  });

  try {
    logger.info('Making HTTP POST request (searchNearby)...', {
      url: test3Url,
      timeout: 10000,
      timestamp: new Date().toISOString(),
    });

    const test3Response = await axios.post(test3Url, test3Payload, {
      headers: test3Headers,
      timeout: 10000,
    });

    logger.info('GOOGLE_RESPONSE_STATUS:', {
      statusCode: test3Response.status,
      statusText: test3Response.statusText,
      timestamp: new Date().toISOString(),
    });
    logger.info('GOOGLE_RESPONSE_HEADERS:', {
      contentType: test3Response.headers['content-type'],
      contentLength: test3Response.headers['content-length'],
      cacheControl: test3Response.headers['cache-control'],
      xGoogRequestId: test3Response.headers['x-goog-request-id'],
      timestamp: new Date().toISOString(),
    });
    logger.info('GOOGLE_RESPONSE_BODY:', {
      body: JSON.stringify(test3Response.data).substring(0, 2000),
      totalLength: JSON.stringify(test3Response.data).length,
      timestamp: new Date().toISOString(),
    });

    testResults.tests.searchNearby = {
      status: 'PASSED',
      httpStatus: test3Response.status,
      statusText: test3Response.statusText,
      responseKeys: Object.keys(test3Response.data),
      placesFound: test3Response.data.places?.length || 0,
      curlCommand: test3CurlCommand,
    };
    testResults.success = true;
  } catch (error) {
    logger.error('=== TEST 3 FAILED ===');
    logger.error('Error details', {
      message: error.message,
      code: error.code,
      status: error.response?.status,
      statusText: error.response?.statusText,
      GOOGLE_RESPONSE_BODY: error.response?.data ? JSON.stringify(error.response.data).substring(0, 1000) : 'No response body',
      timestamp: new Date().toISOString(),
    });

    testResults.tests.searchNearby = {
      status: 'FAILED',
      httpStatus: error.response?.status || 'N/A',
      statusText: error.response?.statusText || error.message,
      errorMessage: error.message,
      errorCode: error.code,
      responseBody: error.response?.data ? JSON.stringify(error.response.data).substring(0, 500) : 'No response body',
      curlCommand: test3CurlCommand,
    };
  }

  // Determine overall success
  const passedTests = Object.values(testResults.tests).filter(t => t.status === 'PASSED').length;
  testResults.summary = {
    totalTests: Object.keys(testResults.tests).length,
    passedTests,
    failedTests: Object.keys(testResults.tests).length - passedTests,
    apiKeyStatus: passedTests > 0 ? 'VALID - At least one test passed' : 'INVALID - All tests failed',
  };

  logger.info('=== TEST SUMMARY ===', testResults.summary);

  res.json(testResults);
});

export default router;
import { Router } from 'express';
import { ContentBlockType, stream, uploadImagesToPocketBase } from '../api/integrated-ai.js';
import { SystemPrompt } from '../constants/prompts.js';
import { uploadFiles } from '../middleware/file-upload.js';
import { integratedAiRateLimit } from '../middleware/integrated-ai-rate-limit.js';
import { pocketbaseAuth } from '../middleware/pocketbase-auth.js';
import logger from '../utils/logger.js';

const router = Router();

router.use(pocketbaseAuth);

/**
 * GET /integrated-ai/health
 * Health check endpoint to verify the integrated AI service is reachable
 * Returns: { status: 'ok', timestamp: ISO string }
 */
router.get('/health', (req, res) => {
	logger.info('GET /integrated-ai/health request received', {
		timestamp: new Date().toISOString(),
		userAgent: req.get('user-agent'),
	});

	res.json({
		status: 'ok',
		timestamp: new Date().toISOString(),
	});
});

/**
 * POST /integrated-ai/stream
 * Stream AI responses using Server-Sent Events (SSE)
 * Accepts multipart form data with message and optional images
 * Returns: SSE stream with { type, content, error } events
 */
router.post('/stream', integratedAiRateLimit, uploadFiles({
	allowedMimeTypes: [
		'image/jpeg',
		'image/png',
		'image/webp',
	],
	fieldName: 'images',
}), async (req, res) => {
	const requestId = `${Date.now()}-${Math.random().toString(36).substring(7)}`;
	const startTime = Date.now();

	logger.info('POST /integrated-ai/stream request received', {
		requestId,
		timestamp: new Date().toISOString(),
		userAgent: req.get('user-agent'),
		hasMessage: !!req.body.message,
		hasImages: !!req.files?.length,
		imageCount: req.files?.length || 0,
		hasCustomerContext: !!req.body.customerContext,
	});

	// Validate message parameter
	if (!req.body.message) {
		logger.error('POST /integrated-ai/stream: Missing message parameter', {
			requestId,
			timestamp: new Date().toISOString(),
		});
		throw new Error('message is required');
	}

	logger.info('Message parameter validated', {
		requestId,
		messageLength: req.body.message.length,
		timestamp: new Date().toISOString(),
	});

	// Parse message JSON
	let parsedMessage;
	try {
		parsedMessage = JSON.parse(req.body.message);
		logger.info('Message parsed successfully', {
			requestId,
			messageType: Array.isArray(parsedMessage) ? 'array' : typeof parsedMessage,
			messageLength: Array.isArray(parsedMessage) ? parsedMessage.length : 1,
			timestamp: new Date().toISOString(),
		});
	} catch (e) {
		logger.error('Failed to parse message JSON', {
			requestId,
			error: e.message,
			messagePreview: req.body.message.substring(0, 100),
			timestamp: new Date().toISOString(),
		});
		throw new Error('Invalid message format. Must be JSON array.');
	}

	// Handle image uploads
	if (req.files?.length > 0) {
		logger.info('Processing uploaded images', {
			requestId,
			imageCount: req.files.length,
			timestamp: new Date().toISOString(),
		});

		try {
			const imageUrls = await uploadImagesToPocketBase({ images: req.files });
			logger.info('Images uploaded successfully', {
				requestId,
				uploadedCount: imageUrls.length,
				timestamp: new Date().toISOString(),
			});

			imageUrls.forEach((url) => {
				parsedMessage.push({ type: ContentBlockType.Image, image: url });
			});
		} catch (imageError) {
			logger.error('Failed to upload images', {
				requestId,
				error: imageError.message,
				timestamp: new Date().toISOString(),
			});
			throw imageError;
		}
	}

	// Prepare system prompt with customer context
	let finalSystemPrompt = SystemPrompt;

	if (req.body.customerContext) {
		logger.info('Processing customer context', {
			requestId,
			contextLength: req.body.customerContext.length,
			timestamp: new Date().toISOString(),
		});

		try {
			const parsedContext = typeof req.body.customerContext === 'string'
				? JSON.parse(req.body.customerContext)
				: req.body.customerContext;

			const contextString = `\n\n--- PROVIDED CUSTOMER CONTEXT ---\nName: ${parsedContext.name || 'Not provided'}\nAddress: ${parsedContext.address || 'Not provided'}\nPhone: ${parsedContext.phone || 'Not provided'}\n---------------------------------\n`;
			finalSystemPrompt = finalSystemPrompt.replace(
				'CUSTOMER CONTEXT INSTRUCTIONS:',
				`CUSTOMER CONTEXT INSTRUCTIONS:${contextString}`
			);

			logger.info('Customer context injected into system prompt', {
				requestId,
				contextName: parsedContext.name || 'Not provided',
				timestamp: new Date().toISOString(),
			});
		} catch (e) {
			logger.warn('Failed to parse customerContext, using default system prompt', {
				requestId,
				error: e.message,
				timestamp: new Date().toISOString(),
			});
		}
	} else if (parsedMessage.length > 0 && parsedMessage[0].type === 'text') {
		// Fallback: Check if the frontend injected context directly into the first text block payload
		const textContent = parsedMessage[0].text || '';
		const contextMatch = textContent.match(/\[CUSTOMER_CONTEXT:(.*)\]/);

		if (contextMatch) {
			logger.info('Found injected customer context in message', {
				requestId,
				timestamp: new Date().toISOString(),
			});

			try {
				const extractedContext = JSON.parse(contextMatch[1]);
				const contextString = `\n\n--- PROVIDED CUSTOMER CONTEXT ---\nName: ${extractedContext.name || 'Not provided'}\nAddress: ${extractedContext.address || 'Not provided'}\nPhone: ${extractedContext.phone || 'Not provided'}\n---------------------------------\n`;
				finalSystemPrompt = finalSystemPrompt.replace(
					'CUSTOMER CONTEXT INSTRUCTIONS:',
					`CUSTOMER CONTEXT INSTRUCTIONS:${contextString}`
				);
				// Remove the injected context from the visible user message
				parsedMessage[0].text = textContent.replace(/\[CUSTOMER_CONTEXT:.*?\]\n*/, '');

				logger.info('Injected customer context processed successfully', {
					requestId,
					contextName: extractedContext.name || 'Not provided',
					timestamp: new Date().toISOString(),
				});
			} catch (e) {
				logger.warn('Failed to parse injected CUSTOMER_CONTEXT', {
					requestId,
					error: e.message,
					timestamp: new Date().toISOString(),
				});
			}
		}
	}

	// Initialize SSE stream
	logger.info('Initializing SSE stream', {
		requestId,
		userId: req.pocketbaseUserId,
		timestamp: new Date().toISOString(),
	});

	let sseStream;
	try {
		sseStream = await stream({
			userId: req.pocketbaseUserId,
			systemPrompt: finalSystemPrompt,
			userMessage: parsedMessage,
			requestId,
		});

		logger.info('SSE stream initialized successfully', {
			requestId,
			timestamp: new Date().toISOString(),
		});
	} catch (streamError) {
		logger.error('Failed to initialize SSE stream', {
			requestId,
			error: streamError.message,
			stack: streamError.stack,
			timestamp: new Date().toISOString(),
		});
		throw streamError;
	}

	// Set SSE response headers
	res.setHeader('Content-Type', 'text/event-stream');
	res.setHeader('Cache-Control', 'no-cache');
	res.setHeader('Connection', 'keep-alive');
	res.setHeader('X-Accel-Buffering', 'no');

	logger.info('SSE response headers set', {
		requestId,
		timestamp: new Date().toISOString(),
	});

	// Pipe stream to response
	sseStream.pipe(res, { end: false });

	logger.info('SSE stream piped to response', {
		requestId,
		timestamp: new Date().toISOString(),
	});

	// Handle client disconnect
	res.on('close', () => {
		const duration = Date.now() - startTime;
		logger.info('Client disconnected from SSE stream', {
			requestId,
			durationMs: duration,
			timestamp: new Date().toISOString(),
		});
		sseStream.destroy();
	});

	// Handle stream errors
	sseStream.on('error', (error) => {
		const duration = Date.now() - startTime;
		logger.error('SSE stream error', {
			requestId,
			error: error.message,
			stack: error.stack,
			durationMs: duration,
			timestamp: new Date().toISOString(),
		});
	});
});

export default router;

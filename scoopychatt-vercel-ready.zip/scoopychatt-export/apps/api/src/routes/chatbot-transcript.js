import express from 'express';
import logger from '../utils/logger.js';
import pb from '../utils/pocketbaseClient.js';

const router = express.Router();

router.post('/', async (req, res) => {
  const { messages, customerInfo, conversationStartTime } = req.body;

  // Validate required fields
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'messages array is required' });
  }

  if (!customerInfo || typeof customerInfo !== 'object') {
    return res.status(400).json({ error: 'customerInfo object is required' });
  }

  if (!conversationStartTime) {
    return res.status(400).json({ error: 'conversationStartTime is required' });
  }

  const { name, email, phone, numberOfDogs, servicePreferences } = customerInfo;

  if (!name || !email) {
    return res.status(400).json({ error: 'customerInfo must include name and email' });
  }

  logger.info('Chatbot transcript received', {
    customerEmail: email,
    customerName: name,
    messageCount: messages.length,
    conversationStartTime,
  });

  // Format the conversation into a readable email body
  const emailBody = formatConversationEmail({
    customerInfo: {
      name,
      email,
      phone: phone || 'Not provided',
      numberOfDogs: numberOfDogs || 'Not specified',
      servicePreferences: servicePreferences || 'Not specified',
    },
    conversationStartTime,
    messages,
  });

  logger.info('Formatted email body', {
    customerEmail: email,
    bodyLength: emailBody.length,
  });

  // Send email using PocketBase's built-in mailer
  const emailData = {
    to: 'brandon@scoopychatt.com',
    subject: 'New Chatbot Inquiry - Scoopy Doo',
    html: emailBody,
  };

  logger.info('Sending email via PocketBase', {
    to: emailData.to,
    subject: emailData.subject,
    customerEmail: email,
    customerName: name,
  });

  // Use PocketBase's built-in mailer
  await pb.send(emailData.to, {
    subject: emailData.subject,
    html: emailData.html,
  });

  logger.info('Email sent successfully via PocketBase', {
    to: emailData.to,
    subject: emailData.subject,
    customerEmail: email,
    customerName: name,
  });

  res.status(200).json({
    success: true,
    message: 'Email sent successfully',
  });
});

/**
 * Format the conversation into a readable HTML email body
 * @param {Object} params - Parameters object
 * @param {Object} params.customerInfo - Customer information
 * @param {string} params.conversationStartTime - ISO timestamp of conversation start
 * @param {Array} params.messages - Array of chat messages
 * @returns {string} Formatted HTML email body
 */
function formatConversationEmail({ customerInfo, conversationStartTime, messages }) {
  const { name, email, phone, numberOfDogs, servicePreferences } = customerInfo;

  // Format the conversation timestamp
  const conversationDate = new Date(conversationStartTime);
  const formattedDate = conversationDate.toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  // Format the chat transcript
  const transcriptHtml = messages
    .map((msg) => {
      const role = msg.role || 'unknown';
      const content = msg.content || '';
      const roleLabel = role.charAt(0).toUpperCase() + role.slice(1);

      return `
        <div style="margin-bottom: 12px; padding: 10px; background-color: ${role === 'user' ? '#f0f0f0' : '#e8f4f8'}; border-left: 4px solid ${role === 'user' ? '#999' : '#0066cc'}; border-radius: 4px;">
          <strong style="color: ${role === 'user' ? '#333' : '#0066cc'};">${roleLabel}:</strong>
          <p style="margin: 8px 0 0 0; color: #333; line-height: 1.5;">${escapeHtml(content)}</p>
        </div>
      `;
    })
    .join('');

  // Build the complete email HTML
  const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          background-color: #f9f9f9;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          background-color: #ffffff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .header {
          border-bottom: 3px solid #0066cc;
          padding-bottom: 15px;
          margin-bottom: 20px;
        }
        .header h1 {
          margin: 0 0 10px 0;
          color: #0066cc;
          font-size: 24px;
        }
        .section {
          margin-bottom: 25px;
        }
        .section-title {
          font-size: 16px;
          font-weight: bold;
          color: #0066cc;
          border-bottom: 2px solid #e0e0e0;
          padding-bottom: 8px;
          margin-bottom: 12px;
        }
        .info-row {
          display: flex;
          margin-bottom: 8px;
        }
        .info-label {
          font-weight: bold;
          width: 150px;
          color: #555;
        }
        .info-value {
          color: #333;
          flex: 1;
        }
        .transcript {
          background-color: #f5f5f5;
          padding: 15px;
          border-radius: 4px;
          max-height: 600px;
          overflow-y: auto;
        }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #e0e0e0;
          font-size: 12px;
          color: #999;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🐕 New Chatbot Inquiry - Scoopy Doo</h1>
          <p style="margin: 0; color: #666; font-size: 14px;">A customer has completed a chat conversation with our AI assistant</p>
        </div>

        <div class="section">
          <div class="section-title">Customer Information</div>
          <div class="info-row">
            <div class="info-label">Name:</div>
            <div class="info-value">${escapeHtml(name)}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Email:</div>
            <div class="info-value"><a href="mailto:${escapeHtml(email)}">${escapeHtml(email)}</a></div>
          </div>
          <div class="info-row">
            <div class="info-label">Phone:</div>
            <div class="info-value">${escapeHtml(phone)}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Number of Dogs:</div>
            <div class="info-value">${escapeHtml(String(numberOfDogs))}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Service Preferences:</div>
            <div class="info-value">${escapeHtml(String(servicePreferences))}</div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Conversation Details</div>
          <div class="info-row">
            <div class="info-label">Start Time:</div>
            <div class="info-value">${formattedDate}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Message Count:</div>
            <div class="info-value">${messages.length} messages</div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Full Chat Transcript</div>
          <div class="transcript">
            ${transcriptHtml}
          </div>
        </div>

        <div class="footer">
          <p>This email was automatically generated from a chatbot conversation on Scoopy's website.</p>
          <p>Sent at: ${new Date().toISOString()}</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return emailHtml;
}

/**
 * Escape HTML special characters to prevent injection
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  };
  return String(text).replace(/[&<>"']/g, (char) => map[char]);
}

export default router;
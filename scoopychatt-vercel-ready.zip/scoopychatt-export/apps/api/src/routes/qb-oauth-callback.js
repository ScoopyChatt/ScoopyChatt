import express from 'express';
import logger from '../utils/logger.js';

const router = express.Router();

router.post('/', async (req, res) => {
  const { code, realmId } = req.body;

  if (!code) {
    return res.status(400).json({ error: 'code is required' });
  }

  if (!realmId) {
    return res.status(400).json({ error: 'realmId is required' });
  }

  logger.info('QuickBooks OAuth callback received', {
    realmId,
    codeLength: code.length,
  });

  const tokenResponse = await fetch('https://oauth.platform.intuit.com/oauth2/tokens/bearer', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      client_id: 'ABGujf9kDh001hHxuyp9nWPPKv7IVr6geqaEBVlJDho5FYGCp0',
      client_secret: 'cx3ZfZ0FMCyHtfhfcefs15nnOTH5wJyB0xm0swkO',
    }).toString(),
  });

  logger.info('QuickBooks token endpoint response received', {
    status: tokenResponse.status,
    statusText: tokenResponse.statusText,
    realmId,
  });

  if (!tokenResponse.ok) {
    const responseText = await tokenResponse.text();
    logger.error('QuickBooks token endpoint error', {
      status: tokenResponse.status,
      statusText: tokenResponse.statusText,
      responseBody: responseText,
      realmId,
    });
    throw new Error(`QuickBooks token endpoint error: ${tokenResponse.status} ${tokenResponse.statusText} - ${responseText}`);
  }

  const tokenData = await tokenResponse.json();

  logger.info('QuickBooks token obtained successfully', {
    realmId,
    tokenType: tokenData.token_type,
    expiresIn: tokenData.expires_in,
  });

  res.json(tokenData);
});

export default router;
import { Router } from 'express';
import logger from '../utils/logger.js';
import healthCheck from './health-check.js';
import quoteWebhookRouter from './quote-webhook.js';
import integratedAiRouter from './integrated-ai.js';
import qbOAuthRouter from './qb-oauth-callback.js';
import googleReviewsRouter from './google-reviews.js';
import chatbotTranscriptRouter from './chatbot-transcript.js';
import leadEmailRouter from './lead-email.js';
import chatSummaryRouter from './chat-summary.js';

const router = Router();

export default () => {
    logger.info('=== ROUTE REGISTRATION START ===', {
        timestamp: new Date().toISOString(),
    });

    // Register health check route
    router.get('/health', healthCheck);
    logger.info('✓ Registered route: GET /health', {
        path: '/health',
        method: 'GET',
        handler: 'healthCheck',
        timestamp: new Date().toISOString(),
    });

    // Register quote webhook route
    router.use('/quote-webhook', quoteWebhookRouter);
    logger.info('✓ Registered route: /quote-webhook', {
        path: '/quote-webhook',
        router: 'quoteWebhookRouter',
        timestamp: new Date().toISOString(),
    });

    // Register integrated AI route
    router.use('/integrated-ai', integratedAiRouter);
    logger.info('✓ Registered route: /integrated-ai', {
        path: '/integrated-ai',
        router: 'integratedAiRouter',
        timestamp: new Date().toISOString(),
    });

    // Register QuickBooks OAuth callback route
    router.use('/qb-oauth-callback', qbOAuthRouter);
    logger.info('✓ Registered route: /qb-oauth-callback', {
        path: '/qb-oauth-callback',
        router: 'qbOAuthRouter',
        timestamp: new Date().toISOString(),
    });

    // Register Google Reviews route
    router.use('/google-reviews', googleReviewsRouter);
    logger.info('✓ Registered route: /google-reviews', {
        path: '/google-reviews',
        router: 'googleReviewsRouter',
        timestamp: new Date().toISOString(),
    });

    // Register Chatbot Transcript route
    router.use('/chatbot-transcript', chatbotTranscriptRouter);
    logger.info('✓ Registered route: /chatbot-transcript', {
        path: '/chatbot-transcript',
        router: 'chatbotTranscriptRouter',
        timestamp: new Date().toISOString(),
    });

    // Register Lead Email route
    router.use('/lead-email', leadEmailRouter);
    logger.info('✓ Registered route: /lead-email', {
        path: '/lead-email',
        router: 'leadEmailRouter',
        timestamp: new Date().toISOString(),
    });

    // Register Chat Summary route (post-chat notifications)
    router.use('/chat-summary', chatSummaryRouter);
    logger.info('✓ Registered route: /chat-summary', {
        path: '/chat-summary',
        router: 'chatSummaryRouter',
        timestamp: new Date().toISOString(),
    });

    // Log complete route summary
    const registeredRoutes = [
        { path: '/health', method: 'GET', handler: 'healthCheck' },
        { path: '/quote-webhook', method: 'POST', handler: 'quoteWebhookRouter' },
        { path: '/integrated-ai', method: 'POST', handler: 'integratedAiRouter' },
        { path: '/qb-oauth-callback', method: 'POST', handler: 'qbOAuthRouter' },
        { path: '/google-reviews', method: 'GET', handler: 'googleReviewsRouter' },
        { path: '/chatbot-transcript', method: 'POST', handler: 'chatbotTranscriptRouter' },
        { path: '/lead-email', method: 'POST', handler: 'leadEmailRouter' },
        { path: '/chat-summary', method: 'POST', handler: 'chatSummaryRouter' },
    ];

    logger.info('=== ROUTE REGISTRATION COMPLETE ===', {
        totalRoutes: registeredRoutes.length,
        routes: registeredRoutes,
        timestamp: new Date().toISOString(),
        accessibleAt: registeredRoutes.map(r => `/hcgi/api${r.path}`),
    });

    return router;
};
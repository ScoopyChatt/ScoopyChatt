import express from 'express';
import logger from '../utils/logger.js';
import pb from '../utils/pocketbaseClient.js';

const router = express.Router();

const REQUIRED_FIELDS = ['name', 'email', 'phone', 'serviceZipCode', 'serviceType', 'numberOfDogs'];
const ZAPIER_WEBHOOK_URL = 'https://hooks.zapier.com/hooks/catch/3191509/ujiqrrz/';

router.post('/', async (req, res) => {
  const { name, email, phone, serviceZipCode, serviceType, numberOfDogs, additionalNotes } = req.body;

  logger.info('Quote webhook received', {
    email,
    serviceType,
    numberOfDogs,
    receivedFields: Object.keys(req.body),
  });

  // Validate required fields
  const missingFields = REQUIRED_FIELDS.filter(field => !req.body[field]);
  if (missingFields.length > 0) {
    logger.warn('Quote webhook: Missing required fields', {
      missingFields,
      email: req.body.email,
      receivedFields: Object.keys(req.body),
    });
    return res.status(400).json({
      error: 'Missing required fields',
      missingFields,
    });
  }

  // Prepare payload for Zapier
  const payload = {
    name,
    email,
    phone,
    serviceZipCode,
    serviceType,
    numberOfDogs,
    additionalNotes: additionalNotes || '',
  };

  logger.info('Prepared Zapier payload', {
    email,
    serviceType,
    numberOfDogs,
    payloadKeys: Object.keys(payload),
  });

  // Forward to Zapier webhook
  logger.info('Sending POST request to Zapier webhook', {
    url: ZAPIER_WEBHOOK_URL,
    email,
    serviceType,
  });

  const zapierResponse = await fetch(ZAPIER_WEBHOOK_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  logger.info('Zapier webhook response received', {
    status: zapierResponse.status,
    statusText: zapierResponse.statusText,
    email,
  });

  if (!zapierResponse.ok) {
    const responseText = await zapierResponse.text();
    logger.error('Zapier webhook error', {
      status: zapierResponse.status,
      statusText: zapierResponse.statusText,
      responseBody: responseText,
      email,
      url: ZAPIER_WEBHOOK_URL,
    });
    throw new Error(`Zapier webhook error: ${zapierResponse.status} ${zapierResponse.statusText} - ${responseText}`);
  }

  logger.info('Quote successfully forwarded to Zapier', {
    email,
    serviceType,
    zapierStatus: zapierResponse.status,
  });

  // Create record in PocketBase 'quote_requests' collection
  // This will trigger the email hook configured in PocketBase
  const formData = {
    name,
    email,
    phone,
    serviceZipCode,
    serviceType,
    numberOfDogs: parseInt(numberOfDogs, 10),
    additionalNotes: additionalNotes || '',
  };

  logger.info('Creating quote request record in PocketBase', {
    email,
    serviceType,
    formDataKeys: Object.keys(formData),
  });

  const createdRecord = await pb.collection('quote_requests').create(formData);

  logger.info('Quote request record created successfully in PocketBase', {
    recordId: createdRecord.id,
    email,
    serviceType,
  });

  res.status(201).json({
    success: true,
    message: 'Quote request received and processed',
    record: createdRecord,
  });
});

export default router;
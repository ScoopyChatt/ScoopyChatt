import express from 'express';
import logger from '../utils/logger.js';
import pb from '../utils/pocketbaseClient.js';

const router = express.Router();

/**
 * POST /lead-email
 * Send lead information email to business owner
 * Accepts: { name, email, phone, address }
 * Returns: { success: true, message: 'Lead information sent successfully' }
 */
router.post('/', async (req, res) => {
  const requestId = `${Date.now()}-${Math.random().toString(36).substring(7)}`;

  logger.info('POST /lead-email request received', {
    requestId,
    timestamp: new Date().toISOString(),
    receivedFields: Object.keys(req.body),
    hasName: !!req.body.name,
    hasEmail: !!req.body.email,
    hasPhone: !!req.body.phone,
    hasAddress: !!req.body.address,
  });

  // Validate required fields
  const { name, email, phone, address } = req.body;

  if (!name) {
    logger.error('POST /lead-email: Missing name field', {
      requestId,
      timestamp: new Date().toISOString(),
      receivedFields: Object.keys(req.body),
    });
    return res.status(400).json({ error: 'name is required' });
  }

  if (!email) {
    logger.error('POST /lead-email: Missing email field', {
      requestId,
      timestamp: new Date().toISOString(),
      receivedFields: Object.keys(req.body),
    });
    return res.status(400).json({ error: 'email is required' });
  }

  if (!phone) {
    logger.error('POST /lead-email: Missing phone field', {
      requestId,
      timestamp: new Date().toISOString(),
      receivedFields: Object.keys(req.body),
    });
    return res.status(400).json({ error: 'phone is required' });
  }

  if (!address) {
    logger.error('POST /lead-email: Missing address field', {
      requestId,
      timestamp: new Date().toISOString(),
      receivedFields: Object.keys(req.body),
    });
    return res.status(400).json({ error: 'address is required' });
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    logger.error('POST /lead-email: Invalid email format', {
      requestId,
      email,
      timestamp: new Date().toISOString(),
    });
    return res.status(400).json({ error: 'email must be a valid email address' });
  }

  logger.info('Lead email validation passed', {
    requestId,
    name,
    email,
    phone,
    address,
    timestamp: new Date().toISOString(),
  });

  // Format the email body with lead details
  const emailBody = formatLeadEmailBody({
    name,
    email,
    phone,
    address,
  });

  logger.info('Formatted lead email body', {
    requestId,
    name,
    email,
    bodyLength: emailBody.length,
    timestamp: new Date().toISOString(),
  });

  // Send email using PocketBase's built-in mailer
  const emailData = {
    to: 'brandon@scoopychatt.com',
    subject: `New Lead Information from Scoopy Chat - ${name}`,
    html: emailBody,
  };

  logger.info('Sending lead email via PocketBase', {
    requestId,
    to: emailData.to,
    subject: emailData.subject,
    leadName: name,
    leadEmail: email,
    timestamp: new Date().toISOString(),
  });

  // Use PocketBase's built-in mailer
  await pb.send(emailData.to, {
    subject: emailData.subject,
    html: emailData.html,
  });

  logger.info('Lead email sent successfully via PocketBase', {
    requestId,
    to: emailData.to,
    subject: emailData.subject,
    leadName: name,
    leadEmail: email,
    timestamp: new Date().toISOString(),
  });

  // Create record in PocketBase 'lead_emails' collection for audit trail
  logger.info('Creating lead email record in PocketBase', {
    requestId,
    name,
    email,
    timestamp: new Date().toISOString(),
  });

  const leadRecord = await pb.collection('lead_emails').create({
    name,
    email,
    phone,
    address,
    sentAt: new Date().toISOString(),
  });

  logger.info('Lead email record created successfully in PocketBase', {
    requestId,
    recordId: leadRecord.id,
    name,
    email,
    timestamp: new Date().toISOString(),
  });

  res.status(200).json({
    success: true,
    message: 'Lead information sent successfully',
    recordId: leadRecord.id,
  });
});

/**
 * Format the lead information into a readable HTML email body
 * @param {Object} params - Parameters object
 * @param {string} params.name - Lead name
 * @param {string} params.email - Lead email address
 * @param {string} params.phone - Lead phone number
 * @param {string} params.address - Lead address
 * @returns {string} Formatted HTML email body
 */
function formatLeadEmailBody({ name, email, phone, address }) {
  const timestamp = new Date().toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          background-color: #f9f9f9;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          background-color: #ffffff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .header {
          border-bottom: 3px solid #0066cc;
          padding-bottom: 15px;
          margin-bottom: 20px;
        }
        .header h1 {
          margin: 0 0 10px 0;
          color: #0066cc;
          font-size: 24px;
        }
        .section {
          margin-bottom: 25px;
        }
        .section-title {
          font-size: 16px;
          font-weight: bold;
          color: #0066cc;
          border-bottom: 2px solid #e0e0e0;
          padding-bottom: 8px;
          margin-bottom: 12px;
        }
        .info-row {
          display: flex;
          margin-bottom: 12px;
        }
        .info-label {
          font-weight: bold;
          width: 120px;
          color: #555;
        }
        .info-value {
          color: #333;
          flex: 1;
          word-break: break-word;
        }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #e0e0e0;
          font-size: 12px;
          color: #999;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🐕 New Lead Information - Scoopy Chat</h1>
          <p style="margin: 0; color: #666; font-size: 14px;">A new lead has submitted their information through the Scoopy chat interface</p>
        </div>

        <div class="section">
          <div class="section-title">Lead Details</div>
          <div class="info-row">
            <div class="info-label">Name:</div>
            <div class="info-value">${escapeHtml(name)}</div>
          </div>
          <div class="info-row">
            <div class="info-label">Email:</div>
            <div class="info-value"><a href="mailto:${escapeHtml(email)}">${escapeHtml(email)}</a></div>
          </div>
          <div class="info-row">
            <div class="info-label">Phone:</div>
            <div class="info-value"><a href="tel:${escapeHtml(phone)}">${escapeHtml(phone)}</a></div>
          </div>
          <div class="info-row">
            <div class="info-label">Address:</div>
            <div class="info-value">${escapeHtml(address)}</div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Submission Details</div>
          <div class="info-row">
            <div class="info-label">Submitted At:</div>
            <div class="info-value">${timestamp}</div>
          </div>
        </div>

        <div class="section">
          <p style="color: #666; font-size: 14px; line-height: 1.6;">
            This lead has expressed interest in Scoopy's pet waste removal services. Follow up with them to discuss their service needs and provide a quote.
          </p>
        </div>

        <div class="footer">
          <p>This email was automatically generated from a lead submission on Scoopy's chat interface.</p>
          <p>Sent at: ${new Date().toISOString()}</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return emailHtml;
}

/**
 * Escape HTML special characters to prevent injection
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  };
  return String(text).replace(/[&<>"']/g, (char) => map[char]);
}

export default router;

import 'dotenv/config';
import logger from './logger.js';

/**
 * Initialize all scheduled cron jobs
 * Call this function once when the server starts
 */
export function initializeCronJobs() {
  logger.info('Initializing cron jobs');
  logger.info('No cron jobs currently scheduled');
  return {};
}

/**
 * Stop all cron jobs (useful for graceful shutdown)
 */
export function stopCronJobs(jobs) {
  logger.info('Stopping cron jobs');
}
import 'dotenv/config';
import axios from 'axios';
import logger from './logger.js';

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
const GOOGLE_BUSINESS_PROFILE_ID = process.env.GOOGLE_BUSINESS_PROFILE_ID;

async function testGoogleAPI() {
  logger.info('=== GOOGLE PLACES API v1 TEST ===');
  logger.info('Testing API call with:', {
    businessProfileId: GOOGLE_BUSINESS_PROFILE_ID,
    apiKeyPrefix: GOOGLE_API_KEY?.substring(0, 10) + '...',
  });

  try {
    const url = `https://places.googleapis.com/v1/places/${GOOGLE_BUSINESS_PROFILE_ID}`;
    const params = {
      fields: 'reviews',
      key: GOOGLE_API_KEY,
    };

    logger.info('Making HTTP request to:', { url, params });

    const response = await axios.get(url, {
      params,
      timeout: 10000,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
    });

    logger.info('=== API RESPONSE SUCCESS ===');
    logger.info('HTTP Status Code:', response.status);
    logger.info('Status Text:', response.statusText);
    logger.info('Response Headers:', response.headers);
    logger.info('Full Response Body (first 1000 chars):', JSON.stringify(response.data).substring(0, 1000));
    logger.info('Response Data Keys:', Object.keys(response.data));

    if (response.data.reviews) {
      logger.info('Reviews Array Found:', {
        reviewCount: response.data.reviews.length,
        firstReviewKeys: response.data.reviews.length > 0 ? Object.keys(response.data.reviews[0]) : [],
        firstReview: response.data.reviews.length > 0 ? JSON.stringify(response.data.reviews[0]).substring(0, 500) : null,
      });
    } else {
      logger.warn('No reviews array in response');
    }

    return response.data;
  } catch (error) {
    logger.error('=== API REQUEST FAILED ===');
    logger.error('Error Message:', error.message);
    logger.error('Error Code:', error.code);
    logger.error('HTTP Status:', error.response?.status);
    logger.error('Status Text:', error.response?.statusText);
    logger.error('Response Body (first 1000 chars):', error.response?.data ? JSON.stringify(error.response.data).substring(0, 1000) : 'No response body');
    logger.error('Response Headers:', error.response?.headers);
    logger.error('Full Error:', error);
    throw error;
  }
}

// Run the test
testGoogleAPI().catch(err => {
  logger.error('Test failed:', err.message);
  process.exit(1);
});
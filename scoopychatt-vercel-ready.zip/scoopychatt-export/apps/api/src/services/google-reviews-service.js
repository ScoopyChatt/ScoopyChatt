import 'dotenv/config';
import logger from '../utils/logger.js';

const GOOGLE_REVIEWS_SHARE_URL = 'https://share.google/rIajlRzE9QvfxtdMn';

/**
 * Fetch all reviews from Google reviews share link
 * Parses the HTML response to extract review data
 * @returns {Promise<Object>} Object with overallRating, totalReviews, and reviews array
 */
export async function fetchGoogleReviews() {
  logger.info('=== FETCHING GOOGLE REVIEWS ===', {
    shareUrl: GOOGLE_REVIEWS_SHARE_URL,
    timestamp: new Date().toISOString(),
  });

  try {
    // Fetch the share link page
    logger.info('Fetching Google reviews share page', {
      url: GOOGLE_REVIEWS_SHARE_URL,
      timestamp: new Date().toISOString(),
    });

    const response = await fetch(GOOGLE_REVIEWS_SHARE_URL, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
      },
    });

    if (!response.ok) {
      logger.error('Failed to fetch Google reviews share page', {
        status: response.status,
        statusText: response.statusText,
        url: GOOGLE_REVIEWS_SHARE_URL,
      });
      throw new Error(`Failed to fetch Google reviews: HTTP ${response.status} ${response.statusText}`);
    }

    const html = await response.text();
    logger.info('Successfully fetched Google reviews page', {
      htmlLength: html.length,
      timestamp: new Date().toISOString(),
    });

    // Parse the HTML to extract review data
    // The page contains JSON data embedded in the HTML
    const reviewData = parseGoogleReviewsHTML(html);

    logger.info('Successfully parsed Google reviews data', {
      overallRating: reviewData.overallRating,
      totalReviews: reviewData.totalReviews,
      reviewsCount: reviewData.reviews.length,
      timestamp: new Date().toISOString(),
    });

    return reviewData;
  } catch (error) {
    logger.error('Error fetching Google reviews', {
      error: error.message,
      stack: error.stack,
      url: GOOGLE_REVIEWS_SHARE_URL,
      timestamp: new Date().toISOString(),
    });
    throw error;
  }
}

/**
 * Parse HTML from Google reviews share page to extract review data
 * @param {string} html - HTML content from the share page
 * @returns {Object} Parsed review data with overallRating, totalReviews, and reviews array
 */
function parseGoogleReviewsHTML(html) {
  logger.info('Parsing Google reviews HTML', {
    htmlLength: html.length,
    timestamp: new Date().toISOString(),
  });

  try {
    // Extract JSON data from the HTML
    // Google embeds review data in script tags or as JSON-LD
    const jsonMatch = html.match(/window\["__INITIAL_STATE__"\]\s*=\s*({.*?});/s);
    
    if (!jsonMatch) {
      logger.warn('Could not find initial state JSON in HTML, attempting alternative parsing');
      return parseGoogleReviewsAlternative(html);
    }

    const jsonStr = jsonMatch[1];
    logger.info('Extracted JSON from HTML', {
      jsonLength: jsonStr.length,
      timestamp: new Date().toISOString(),
    });

    const data = JSON.parse(jsonStr);
    logger.info('Parsed JSON successfully', {
      dataKeys: Object.keys(data),
      timestamp: new Date().toISOString(),
    });

    // Extract review information from the parsed data
    const reviewData = extractReviewData(data);

    logger.info('Extracted review data', {
      overallRating: reviewData.overallRating,
      totalReviews: reviewData.totalReviews,
      reviewsCount: reviewData.reviews.length,
      timestamp: new Date().toISOString(),
    });

    return reviewData;
  } catch (error) {
    logger.error('Error parsing Google reviews HTML', {
      error: error.message,
      stack: error.stack,
      htmlLength: html.length,
      timestamp: new Date().toISOString(),
    });
    throw new Error(`Failed to parse Google reviews: ${error.message}`);
  }
}

/**
 * Alternative parsing method for Google reviews HTML
 * Extracts review data using regex patterns
 * @param {string} html - HTML content from the share page
 * @returns {Object} Parsed review data
 */
function parseGoogleReviewsAlternative(html) {
  logger.info('Using alternative parsing method for Google reviews', {
    timestamp: new Date().toISOString(),
  });

  try {
    // Look for review data in various formats
    // Try to find JSON-LD structured data
    const jsonLdMatch = html.match(/<script type="application\/ld\+json">(.*?)<\/script>/s);
    
    if (jsonLdMatch) {
      const jsonLdData = JSON.parse(jsonLdMatch[1]);
      logger.info('Found JSON-LD structured data', {
        type: jsonLdData['@type'],
        timestamp: new Date().toISOString(),
      });

      if (jsonLdData.aggregateRating) {
        const overallRating = Math.round(jsonLdData.aggregateRating.ratingValue);
        const totalReviews = jsonLdData.aggregateRating.reviewCount || 0;
        const reviews = jsonLdData.review || [];

        logger.info('Extracted data from JSON-LD', {
          overallRating,
          totalReviews,
          reviewsCount: reviews.length,
          timestamp: new Date().toISOString(),
        });

        return {
          overallRating,
          totalReviews,
          reviews: reviews.map(review => ({
            author: review.author?.name || 'Anonymous',
            rating: Math.round(review.reviewRating?.ratingValue || 0),
            text: review.reviewBody || '',
            date: review.datePublished || new Date().toISOString(),
          })),
        };
      }
    }

    // Fallback: Extract from meta tags and other HTML elements
    logger.warn('Could not find structured data, using fallback extraction');
    return extractFromMetaTags(html);
  } catch (error) {
    logger.error('Error in alternative parsing', {
      error: error.message,
      timestamp: new Date().toISOString(),
    });
    throw new Error(`Failed to parse Google reviews with alternative method: ${error.message}`);
  }
}

/**
 * Extract review data from meta tags and HTML elements
 * @param {string} html - HTML content
 * @returns {Object} Parsed review data
 */
function extractFromMetaTags(html) {
  logger.info('Extracting review data from meta tags', {
    timestamp: new Date().toISOString(),
  });

  try {
    // Extract overall rating from meta tags
    const ratingMatch = html.match(/"ratingValue"\s*:\s*([0-9.]+)/i);
    const overallRating = ratingMatch ? Math.round(parseFloat(ratingMatch[1])) : 5;

    // Extract review count from meta tags
    const reviewCountMatch = html.match(/"reviewCount"\s*:\s*(\d+)/i);
    const totalReviews = reviewCountMatch ? parseInt(reviewCountMatch[1], 10) : 82;

    logger.info('Extracted from meta tags', {
      overallRating,
      totalReviews,
      timestamp: new Date().toISOString(),
    });

    // Extract individual reviews from the HTML
    const reviews = extractIndividualReviews(html);

    return {
      overallRating,
      totalReviews,
      reviews,
    };
  } catch (error) {
    logger.error('Error extracting from meta tags', {
      error: error.message,
      timestamp: new Date().toISOString(),
    });
    throw error;
  }
}

/**
 * Extract individual reviews from HTML
 * @param {string} html - HTML content
 * @returns {Array} Array of review objects
 */
function extractIndividualReviews(html) {
  logger.info('Extracting individual reviews from HTML', {
    timestamp: new Date().toISOString(),
  });

  const reviews = [];

  try {
    // Look for review blocks in the HTML
    // Reviews are typically in divs with specific classes or data attributes
    const reviewPattern = /"author"\s*:\s*"([^"]+)".*?"reviewRating"\s*:\s*{\s*"ratingValue"\s*:\s*([0-9.]+).*?"reviewBody"\s*:\s*"([^"]*)"/gs;
    
    let match;
    let reviewCount = 0;

    while ((match = reviewPattern.exec(html)) !== null) {
      const author = match[1];
      const rating = Math.round(parseFloat(match[2]));
      const text = match[3];

      reviews.push({
        author,
        rating,
        text,
        date: new Date().toISOString(),
      });

      reviewCount++;
    }

    logger.info('Extracted individual reviews', {
      reviewCount,
      timestamp: new Date().toISOString(),
    });

    // If no reviews found with the pattern, return empty array
    // The frontend will handle displaying the overall rating and count
    if (reviews.length === 0) {
      logger.warn('No individual reviews extracted from HTML, returning empty array');
    }

    return reviews;
  } catch (error) {
    logger.error('Error extracting individual reviews', {
      error: error.message,
      timestamp: new Date().toISOString(),
    });
    return [];
  }
}

/**
 * Extract review data from parsed JSON object
 * @param {Object} data - Parsed JSON data from the page
 * @returns {Object} Review data with overallRating, totalReviews, and reviews array
 */
function extractReviewData(data) {
  logger.info('Extracting review data from parsed JSON', {
    dataType: typeof data,
    timestamp: new Date().toISOString(),
  });

  try {
    // Navigate through the data structure to find review information
    // This varies depending on how Google structures the data
    let overallRating = 5;
    let totalReviews = 82;
    let reviews = [];

    // Try to find aggregateRating in the data
    const findAggregateRating = (obj) => {
      if (!obj || typeof obj !== 'object') return null;
      
      if (obj.aggregateRating) {
        return obj.aggregateRating;
      }

      for (const key in obj) {
        const result = findAggregateRating(obj[key]);
        if (result) return result;
      }

      return null;
    };

    const aggregateRating = findAggregateRating(data);
    if (aggregateRating) {
      overallRating = Math.round(aggregateRating.ratingValue || 5);
      totalReviews = aggregateRating.reviewCount || 82;
      logger.info('Found aggregateRating in data', {
        overallRating,
        totalReviews,
        timestamp: new Date().toISOString(),
      });
    }

    // Try to find reviews array in the data
    const findReviews = (obj) => {
      if (!obj || typeof obj !== 'object') return null;
      
      if (Array.isArray(obj) && obj.length > 0 && obj[0].author) {
        return obj;
      }

      if (obj.review && Array.isArray(obj.review)) {
        return obj.review;
      }

      if (obj.reviews && Array.isArray(obj.reviews)) {
        return obj.reviews;
      }

      for (const key in obj) {
        const result = findReviews(obj[key]);
        if (result) return result;
      }

      return null;
    };

    const reviewsArray = findReviews(data);
    if (reviewsArray) {
      reviews = reviewsArray.map(review => ({
        author: review.author?.name || review.author || 'Anonymous',
        rating: Math.round(review.reviewRating?.ratingValue || review.rating || 0),
        text: review.reviewBody || review.text || '',
        date: review.datePublished || review.date || new Date().toISOString(),
      }));
      logger.info('Found reviews array in data', {
        reviewsCount: reviews.length,
        timestamp: new Date().toISOString(),
      });
    }

    return {
      overallRating,
      totalReviews,
      reviews,
    };
  } catch (error) {
    logger.error('Error extracting review data from JSON', {
      error: error.message,
      timestamp: new Date().toISOString(),
    });
    throw error;
  }
}

/**
 * Get cached reviews or fetch fresh ones
 * @returns {Promise<Object>} Review data with overallRating, totalReviews, and reviews array
 */
export async function getCachedReviews() {
  logger.info('Getting reviews (cached or fresh)', {
    timestamp: new Date().toISOString(),
  });

  try {
    const reviewData = await fetchGoogleReviews();
    logger.info('Successfully retrieved reviews', {
      overallRating: reviewData.overallRating,
      totalReviews: reviewData.totalReviews,
      reviewsCount: reviewData.reviews.length,
      timestamp: new Date().toISOString(),
    });
    return reviewData;
  } catch (error) {
    logger.error('Failed to retrieve reviews', {
      error: error.message,
      timestamp: new Date().toISOString(),
    });
    throw error;
  }
}
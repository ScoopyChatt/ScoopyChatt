import rateLimit from 'express-rate-limit';
import logger from '../utils/logger.js';

export const integratedAiRateLimit = rateLimit({
	windowMs: 60 * 1000, // 1 minute window
	max: 30, // Allow 30 requests per minute (0.5 requests per second)
	standardHeaders: true,
	legacyHeaders: false,
	message: { error: 'Too many AI requests, please try again later' },
	validate: { trustProxy: false },
	handler: (req, res, next, options) => {
		logger.warn('Rate limit exceeded for /integrated-ai/stream', {
			ip: req.ip,
			path: req.path,
			timestamp: new Date().toISOString(),
		});
		res.status(options.statusCode).json(options.message);
	},
	skip: (req) => {
		// Skip rate limiting for health check
		if (req.path === '/health') {
			return true;
		}
		return false;
	},
});
